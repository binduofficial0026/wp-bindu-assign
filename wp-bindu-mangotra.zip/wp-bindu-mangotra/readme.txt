WP Bindu Bindu
===============

Simple plugin that adds a Products > Coupons manager.

Installation:
1. Upload the `wp-bindu-bindu` folder to your `/wp-content/plugins/` directory.
2. Activate the plugin through the 'Plugins' screen in WordPress admin.
3. A 'Products' menu will appear with 'Coupons' and 'Add Coupon'.

Notes:
- Data stored in custom table: database_prefix_coupons_bindu_bindu
- Table created automatically on activation.
- Server-side validation is used.
- Translation ready (textdomain: wp-bindu-bindu).
